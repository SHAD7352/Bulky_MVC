using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BulkyWebRazor_Temp.Pages.Shared
{
    public class _NotificationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
